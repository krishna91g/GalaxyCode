package com.galaxy.merchant;

import java.util.ArrayList;

/**
 * @author Krishna G
 * <p>This class is the starting point of the application.<br>
 * Kindly see the <b>package-info.java</b> for assumptions made in the application</p>
 * 
 */
public class GalaxyApplication {

	/**
	 * <p>Entry point of the application</p>
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		
		System.out.println("Welcome to GalaxyMerchant !!!!! please provide Test input below and a blank new line to finish input");
		Paragraph paragraph = new Paragraph();		
		// Read the input from console, validate and process
		ArrayList<String> output=paragraph.read();
		if(output.size()>0) {
			System.out.println("Test Output is as below -->\n");}
		for(int i=0;i<output.size();i++){			
			System.out.println(output.get(i));
		}
		
		
	}

}
